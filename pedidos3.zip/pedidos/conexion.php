<?php
require 'vendor/autoload.php';  // Barra normal
use Dotenv\Dotenv;

// Carga .env de manera que permita usar getenv()
$dotenv = Dotenv::createUnsafeImmutable(__DIR__);
$dotenv->load();


// Obtiene las variables de entorno
$host = getenv('DB_HOST');
$user = getenv('DB_USER');
$clave = getenv('DB_PASSWORD');
$db = getenv('DB_NAME');

$conection = @mysqli_connect($host, $user, $clave, $db);
if (!$conection) {
    die('Error de conexión: ' . mysqli_connect_error());
}

$_SESSION['db'] = "$db-";
