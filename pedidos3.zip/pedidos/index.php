<?php
// Verificar si la solicitud llega a la versión con www
if (substr($_SERVER['HTTP_HOST'], 0, 4) === 'www.') {
    // Redireccionar a la misma URL sin www
    $url = "http://" . substr($_SERVER['HTTP_HOST'], 4) . $_SERVER['REQUEST_URI'];
    header("HTTP/1.1 301 Moved Permanently");
    header("Location: $url");
    exit();
}
//CACHE
// header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
// header("Cache-Control: post-check=0, pre-check=0", false);
// header("Pragma: no-cache");

$alert = '';
session_start();
$_SESSION['db'] ??= '';
require_once "conexion.php";
if(!empty($_SESSION[$_SESSION['db'].'active'])) {
    header('location: sistema/');
    exit();
} else {
    if(!empty($_POST)) {
        if(empty($_POST['usuario']) || empty($_POST['clave'])){
            $alert = 'Ingrese su usuario y su contraseña';
        } else { // Verificando credenciales

            // Obtener el usuario y la contraseña del formulario
            $usuario = $_POST['usuario'];
            $pass = md5($_POST['clave']);  // Considera utilizar métodos más seguros para el hash de contraseñas

            // Preparar la consulta con placeholders (?)
            $query = "SELECT id, des_usr, usr_email, cdg_usr, niv_usr, psw_usr, is_logged_in, last_activity, so, swt_usr, 
                            GROUP_CONCAT(CONCAT(d.id_dopcion, '-', d.lec_item)) AS combined_array,
                            (SELECT CREF1 FROM t_tablas) AS exceso 
                    FROM m_usuari m 
                    LEFT JOIN d_usuari d ON m.id = d.id_musuari 
                    WHERE m.cdg_usr = ? AND m.swt_usr = 1 
                    GROUP BY id, des_usr, usr_email, cdg_usr, niv_usr, psw_usr, is_logged_in, last_activity, so, swt_usr";

            // Preparar la sentencia
            $stmt = mysqli_prepare($conection, $query);

            // Vincular parámetros
            mysqli_stmt_bind_param($stmt, "s", $usuario);

            // Ejecutar la consulta
            mysqli_stmt_execute($stmt);

            // Obtener el resultado
            $result = mysqli_stmt_get_result($stmt);

            // Verificar si se encontraron resultados
            if(mysqli_num_rows($result) > 0) {
                $data = mysqli_fetch_array($result);

                // Dividir la cadena combinada en un array asociativo
                $combinedArray = [];
                $pairs = explode(',', $data['combined_array']);
                if($data['combined_array']){
                    foreach ($pairs as $pair) {
                        [$id_dopcion, $lec_item] = explode('-', $pair);
                        $combinedArray[$id_dopcion] = $lec_item;
                    }
                }

            // Liberar los recursos
            mysqli_stmt_close($stmt);
            //COMENTAR PARA HOSTING
            date_default_timezone_set('America/Lima');
            
            // Obtiene la fecha y hora actual en formato de marca de tiempo UNIX
            $now = time();
            $last_activity = strtotime($data["last_activity"]);
            $time_difference = $now - $last_activity;
            $current_date = date('Y-m-d H:i:s');
            //tiempo a minutos
            $minutes_difference = floor($time_difference / 60);
            // Verifica si han pasado más de X minutos desde la última actividad
            if ($minutes_difference >= 1) {
                // Si han pasado más de X minutos, marca al usuario como no conectado
                $update = mysqli_query($conection, "UPDATE m_usuari SET is_logged_in = 0 WHERE id = " . $data['id']);
                $data['is_logged_in'] = 0;
            }else if ($minutes_difference < 0){
                $update = mysqli_query($conection, "UPDATE m_usuari SET last_activity = '$current_date' WHERE id = " . $data['id']);
                $data['is_logged_in'] = 1;
            }
            
            if($data['is_logged_in'] == 1) {
                $alert = 'Usuario conectado desde: '.$data['so'].'';

            } else {
                //número aleatorio 
                $random_key = mt_rand(); // Puedes usar mt_rand() para generar un número aleatorio seguro

                // Establece una cookie con el número aleatorio
                setcookie('user_key', $random_key, time() + 10*60*60, '/'); // 36000 cookie expira en 10 horas
                // Almacena el número aleatorio en la base de datos
                $query = mysqli_query($conection, "UPDATE m_usuari SET user_key = '$random_key' WHERE id = " . $data['id']);

                // Verifica la contraseña
                if($data['psw_usr'] === $pass) {
                    // Actualiza el estado a conectado y última actividad
                    $update_query = mysqli_query($conection, "UPDATE m_usuari SET is_logged_in = 1, last_activity = '$current_date' WHERE id = " . $data['id']);

                    // Inicia la sesión del usuario
                    $idUser = $data['id'];
                    $_SESSION[$_SESSION['db'].'active'] = true;
                    $_SESSION[$_SESSION['db'].'idUser'] = $idUser;
                    $_SESSION[$_SESSION['db'].'nombre'] = $data['des_usr'];
                    $_SESSION[$_SESSION['db'].'correo'] = $data['usr_email'];
                    $_SESSION[$_SESSION['db'].'usuario'] = $data['cdg_usr'];
                    $_SESSION[$_SESSION['db'].'rol'] = $data['niv_usr'];
                    $_SESSION[$_SESSION['db'].'opcion'] = 'Inicio';  // Inicia 
                    $_SESSION[$_SESSION['db'].'perms'] = $combinedArray??'';
                    //Opciones de sistema
                    $_SESSION[$_SESSION['db'].'exceso'] = $data['exceso'];
                    

                    //Guardar el sistema operativo en la base de datos
                    $userAgent = $_SERVER['HTTP_USER_AGENT'];
                    // Expresión regular para extraer el sistema operativo
                    $regex = '/\(([^)]+)\)/';
                    // if (preg_match($regex, $userAgent, $matches)) {
                    //     $operatingSystem = $matches[1];
                    // } else {
                    //     $operatingSystem = "No se pudo determinar el sistema operativo.";
                    // }
                    $operatingSystem = preg_match($regex, $userAgent, $matches)?$matches[1]:"No se pudo determinar el sistema operativo.";
                    $query_so = mysqli_query($conection,"UPDATE m_usuari SET  so = '$operatingSystem' WHERE id = $idUser");
                    header('location: sistema/');
                } else {
                    $alert = 'El usuario o la contraseña son incorrectas';
                    session_destroy();
                }
            }
        } else {
            $alert = 'El usuario o la contraseña son incorrectas o el usuario se encuentra desactivado';
            session_destroy();
        }

        // Cerrar la conexión con la base de datos
        mysqli_close($conection);
    }
}
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Sistema ERP</title>
    <link rel="icon" href="img/dollar.ico">
<!-- //font-awesome -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>

    <script type="text/javascript" src="js/function.js" defer></script>
    <script type="text/javascript" src="sistema/js/jquery.min.js" ></script>
    <link rel="stylesheet" href="css/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />
</head>
<body>
    <div class="wrapper">
        <span class="bg-animate"></span>
        <span class="bg-animate2"></span>
        <section id="login-container" class="login">
            <div class="login__title">
                <h1 class="title"><strong id="t1">LAZZAR</strong> <strong id="t2">SOLUTIONS</strong> </h1>
                <div class="logo-top">
                    <img class="logo-top_l" src="img/now.png" alt="Logo ERP NOW">
                </div>
            </div>
            <form class="login__form" action="" method="post">
                <div class="input-box animation">
                    <input id="usuario" class="form__user" type="text" name="usuario" value=""  title="Ingrese su usuario" autocomplete="username">
                    <span class="animated-placeholder">Usuario</span>
                </div>
                <div class="input-box animation">
                    <input id="clave" class="form__pass" type="password" name="clave" value=""  title="Ingrese su contraseña" autocomplete="current-password">
                    <span class="animated-placeholder">Contraseña</span><i id="view_pass_icon" class="fa-solid fa-eye-slash" title="Ver contraseña" style="color: #7a7a7a;"></i>
                </div>
                <button type="submit" class="btn animation" title="Ingresar">Login</button>
                <a href="https://lzzsol.com/" target="_blank" title="Página web">Descubre quiénes somos<span class="material-symbols-outlined">Open_In_New</span></a>
                <div class="alert"><p><?php echo $alert ?? ''; ?></p></div>
            </form>
        </section>
        <section class="login-right">
            <img src="img/erpnow.jpg" alt="ERP NOW">
        </section>
    </div>
    <script>localStorage.removeItem('selectedTab');</script>
</body>

</html>
