DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `changeCoinDetails`(IN `in_mon` INT, IN `in_fec` DATE, IN `in_id_mped` INT, IN `in_token` VARCHAR(50), IN `in_lista` INT)
BEGIN
    DECLARE var_tcambio DECIMAL(20, 10) DEFAULT 1;  -- Default tipo de cambio es 1 si no se encuentra otro valor

    -- Trayendo el valor del tipo de cambio según fecha (1 si no existe)
    SELECT COALESCE(
        CASE 
            WHEN TCV_VENTA IS NULL OR TCV_VENTA = 0 THEN 
                CASE WHEN TIP_CMB = 0 THEN 1 ELSE TIP_CMB END
            ELSE 
                TCV_VENTA
        END, 1
    ) INTO var_tcambio
    FROM t_cambio
    WHERE FEC_CMB = in_fec;

    -- Ahora actualizamos los valores en la tabla `detalle_temp`
    UPDATE detalle_temp d
    LEFT JOIN m_lista m ON d.codproducto = m.ID_MPRODUC
                         AND d.id_mclient = m.id_mclient
                         AND m.ID_DTAB_CDGLIST = in_lista
    SET 
        -- Actualización de precio_venta convertido según moneda
        d.precio_venta = CASE 
                            WHEN d.ID_DTAB_MON = in_mon THEN d.precio_venta
                            ELSE 
                                CASE 
                                    WHEN d.ID_DTAB_MON = in_mon THEN d.precio_venta / var_tcambio 
                                    ELSE d.precio_venta * var_tcambio
                                END
                         END,
        -- Actualización de PRE_SOL y PRE_DOL desde la tabla m_lista
        d.val_sol = m.PRE_SOL,
        d.val_dol = m.PRE_DOL
    WHERE d.id_mpedido = in_id_mped 
      AND d.token_user = in_token;

END$$
DELIMITER ;