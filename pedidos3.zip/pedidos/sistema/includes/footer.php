<div class="footer">
    <p>© 2024 Lazzar Solutions. Todos los derechos reservados.
    </p>
</div>